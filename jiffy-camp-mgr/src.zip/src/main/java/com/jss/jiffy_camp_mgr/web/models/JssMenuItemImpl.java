package com.jss.jiffy_camp_mgr.web.models;

import java.util.List;

public class JssMenuItemImpl {
	
	
	List<JssMenuItem> subMenuList;
	
	public JssMenuItemImpl() {}

	public List<JssMenuItem> getSubMenuList() {
		return subMenuList;
	}

	public void setSubMenuList(List<JssMenuItem> subMenuList) {
		this.subMenuList = subMenuList;
	}
	

}
