package com.jss.jiffy_camp_mgr.dao.entities;

public class SystemConfig {

}
