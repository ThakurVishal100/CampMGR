package com.jss.jiffy_camp_mgr.dao.services;

public interface ConfigService {

}
