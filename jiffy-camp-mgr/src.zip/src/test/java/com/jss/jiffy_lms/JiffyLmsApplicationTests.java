package com.jss.jiffy_lms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JiffyLmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
